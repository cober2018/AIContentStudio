# 人工交付说明

- 渠道：xiaohongshu / image_note
- 候选哈希：9a3bcfa817c383b698994b85f59fd9805f2b1c307dc41fff5f003dd349f78d0d
- 动作：copy_package

本地包就绪不等于公开发布；公众号草稿也不等于公开发布。按 manifest.media 的顺序和位置使用精确素材，并保留 sources.json 和 declarations.json 的来源、署名与声明。HTML 为本产品的安全排版，平台编辑器可能改变样式。X 长帖/Articles 账号资格未验证，不影响本地交付。抖音内容为脚本，字幕为估算，不是成片或音频对齐字幕。本包没有调用远端；发布后人工回填真实回执。
